<?php 
$month = date("m");
echo $month;